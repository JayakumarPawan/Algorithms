import sys
from math import pi , acos , sin , cos
import pickle
from tkinter import *
from PIL import ImageTk, Image
import heapq
#
# nodes = []
# with open("nodes.txt",'r') as f:
#     lines = f.readlines()
#     nodes = [line.rstrip().split(" ") for line in lines]
#
# edges = []
# with open("edges.txt",'r') as f:
#     lines = f.readlines()
#     edges = [line.rstrip().split(" ") for line in lines]
#
# id_to_name = {}
#
# with open("id-name.txt",'r') as f:
#     lines = f.readlines()
#     for line in lines:
#         parts = line.rstrip().split(" ")
#         id_to_name[parts[0]] = parts[1]
#
# # long goes from 14.69 to 60.85 lat goes from -130.36 to -60.02
# # # NewValue = (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
nodes = pickle.load(open('nodes.pkl','rb'))
drawCoords = {}
for n in nodes:
    newLong = int(933)- int(((n[1] - 14.69) * (933)) / (46.16))
    newLat = int(((n[2] +130.36) * (1464)) / (-60.02 + 130.36))
    drawCoords[n[0]] = (newLong, newLat)

# print(f"min lat: {min([node[1] for node in nodes])} max lat:   {max([node[1] for node in nodes])}")
# print(f"min long: {min([node[2] for node in nodes])} max long: {max([node[2] for node in nodes])}")
# pickle.dump(nodes,open('nodes.pkl','wb'))
# pickle.dump(edges,open('edges.pkl','wb'))
# pickle.dump(id_to_name,open('id_to_name.pkl','wb'))

class Node:
    def __init__(self,id,long,lat):
        self.id=id
        self.lat=lat
        self.long=long
        self.neighbors={}
        self.name = id_to_name[id] if id in id_to_name.keys() else id
        self.parent = "none"
        self.depth =0
        self.f = 0
    def __str__(self):
        return f"Station name: {self.name}   station id: {self.id}   coordinates: ({self.lat} , {self.long})"
    def __repr__(self):
        return self.__str__()
    def __lt__(self, other):
        return self.f - other.f
    def __eq__(self, other):
        return self.id == other.id

    def __hash__(self):
        return int(self.long)+int(self.lat)
    def addNeighbor(self, n):
        neighbors[n] = calcd(self.long,self.lat,n.long,n.lat)
def calcd(y1,x1, y2,x2):
   #domain error if distance is 0
   # y1 = lat1, x1 = long1
   # y2 = lat2, x2 = long2
   # all assumed to be in decimal degree
   y1  = float(y1)
   x1  = float(x1)
   y2  = float(y2)
   x2  = float(x2)
   R   = 3958.76 # miles = 6371 km
   y1 *= pi/180.0
   x1 *= pi/180.0
   y2 *= pi/180.0
   x2 *= pi/180.0
   return acos( sin(y1)*sin(y2) + cos(y1)*cos(y2)*cos(x2-x1) ) * R
def create_circle(x, y, r, canvasName, c,f = None):
    #center coordinates, radius,c,color
    x0 = x - r
    y0 = y - r
    x1 = x + r
    y1 = y + r
    if f:
        return canvasName.create_oval(x0, y0, x1, y1,outline=c,fill=f)
    else:
        return canvasName.create_oval(x0, y0, x1, y1,outline=c)

def handleInput(args,name_to_id): #sys.argv
    if len(args) <3:
        return '8801752', '9100327'
    if len(args) == 3:
        return (name_to_id[args[1]],name_to_id[args[2]])
    if len(args) ==4:
        city1a = args[1]+" "+args[2]
        if(city1a in name_to_id.keys()):
            return name_to_id[city1a],name_to_id[args[3]]

        else:
            city2 = name_to_id[args[2]+" "+args[3]]
            return name_to_id[args[1]], city2

    if len(args) ==5:
        city1 = name_to_id[args[1]+" "+args[2]]
        city2 = name_to_id[args[3]+" "+args[4]]
        return city1, city2


def h(cur, goal):
    return calcd(cur.long,cur.lat,goal.long,goal.lat)

def getPath(cur,end,drawCoords,c, closedDict):
    dist = 0
    path  = []
    start = cur
    while cur!=end:
        if cur in closedDict.keys():
            p,l = closedDict[n]
            c.delete(p)
            c.delete(l)
        path.append(cur)
        cur = cur.parent
    path = path[::-1]
    for i in range(1,len(path)):
        create_circle(drawCoords[path[i].id][1],drawCoords[path[i].id][0],1,c,green)
        c.create_line(drawCoords[path[i].id][1],drawCoords[path[i].id][0], drawCoords[path[i-1].id][1],drawCoords[path[i-1].id][0],fill=green )
        if type(path[i] ==cur):
            print(path[i].id," distance: ",path[i].depth - path[i-1].depth, " mi")
    print(start.id, "distance: ", start.depth-start.parent.depth, " mi" )
    print("totalDistance: ", start.depth, " mi")

edges = pickle.load(open('edges.pkl','rb'))

id_to_name =  pickle.load(open('id_to_name.pkl','rb'))


network = { node1[0]:Node(node1[0], node1[1], node1[2]) for node1 in nodes}

for edge in edges:
    distance = calcd(network[edge[0]].long,network[edge[0]].lat,network[edge[1]].long,network[edge[1]].lat)
    network[edge[0]].neighbors[network[edge[1]]] = distance
    network[edge[1]].neighbors[network[edge[0]]] = distance

sys.setrecursionlimit(10000)
# pickle.dump(network, open("graph.pkl",'wb'))
pickle.dump(drawCoords, open("drawCoords.pkl",'wb'))


# network = pickle.load(open('graph.pkl','rb'))
drawCoords = pickle.load(open('drawCoords.pkl','rb'))
name_to_id = pickle.load(open('name_to_id.pkl','rb'))
red = '#ff0000' #open
blue = '#0000FF'	#closed
green = '#008000' #path
window = Tk()
window.title("choo choo!")
window.geometry("1500x1000")
window.configure(background='grey')
imagefile = "map2.png"
img = PhotoImage(file=imagefile)
c = Canvas(width=img.width(),height=img.height())
c.pack()
c1,c2 = handleInput(sys.argv,name_to_id)
start = network[c1]
goal = network[c2]

create_circle(drawCoords[start.id][1],drawCoords[start.id][0],1,c,red)
for id in network.keys():
    create_circle(drawCoords[id][1],drawCoords[id][0], 1,c,'#000000')

upd = 0
lineDict = {}
closedDict = {}
openSet =[]
start.f = h(start,goal)
heapq.heappush(openSet, start)
closedSet = set()
while openSet:
    cur = heapq.heappop(openSet)
    if(cur in closedSet):
        continue
    closedSet.add(cur)
    if cur!= start:
        p,l = lineDict[cur]
        c.delete(p)
        c.delete(l)
        p = c.create_line(drawCoords[cur.id][1],drawCoords[cur.id][0], drawCoords[cur.parent.id][1],drawCoords[cur.parent.id][0],fill='blue')
        l = create_circle(drawCoords[cur.id][1],drawCoords[cur.id][0],1,c,blue)
        closedDict[cur] = (p,l)
    if(cur == goal):
        getPath(cur,start,drawCoords,c,closedDict)
        break
    for n,d in cur.neighbors.items():
        if n in closedSet:
            continue
        n.parent = cur
        n.depth = cur.depth+d
        n.f = h(n,goal)+n.depth
        heapq.heappush(openSet, n)
        p = create_circle(drawCoords[cur.id][1],drawCoords[cur.id][0],1,c,red)
        l = c.create_line(drawCoords[cur.id][1],drawCoords[cur.id][0], drawCoords[n.id][1],drawCoords[n.id][0],fill='red')
        lineDict[n] = (p,l)
    if not upd%100:
        window.update()
    upd+=1


mainloop()
